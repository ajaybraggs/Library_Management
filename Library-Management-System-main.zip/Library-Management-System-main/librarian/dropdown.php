					<li>		
					<a href="borrow.php"  data-toggle="dropdown"> Transaction</a>
					<ul class="dropdown-menu">
					<li><a href="borrow.php">&nbsp;Borrow</a></li>
					<li><a href="return.php">&nbsp;View Returned Books</a></li>
					<li><a href="view_borrow.php">&nbsp;View Borrowed Books</a></li>
					</ul>
					</li>