<?php
$servername="localhost";
$username="root";
$password="";
$database="eb_lms";
$conn=mysqli_connect($servername,$username,$password,$database);

?>