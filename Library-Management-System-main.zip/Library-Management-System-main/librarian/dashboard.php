<?php include('header.php'); ?>
<?php include('session.php'); ?>
<?php include('navbar_dashboard.php'); ?>
<div class="container">
    <div class="margin-top">
        <div class="row">
            <div class="span12">

                <!-- <?php include('slider.php'); ?> -->

                <div data-thumb="LMS/EB2.jpg">
                    <img
                        src="https://th.bing.com/th/id/R.4bb098a29740649b0bc2cb8670261c31?rik=vEBxa42jkWNvOQ&riu=http%3a%2f%2fems.nmamit.in%2fven_pic%2f8640053_orig.jpg&ehk=InkbLKCvjjsOZnxlgg2zR%2bfS9jTtI69wwI0lQH633cA%3d&risl=&pid=ImgRaw&r=0">
                </div>


            </div>
        </div>
    </div>
</div>
<?php include('footer.php') ?>