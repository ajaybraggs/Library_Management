		<div>
		    <div>
		        <div>
		            <img src="https://nmamit.nitte.edu.in/img/nitte-nmamit-logo.png" width="100%">
		        </div>
		    </div>

		    <div class=" alert alert-info">Welcome to NITTE University Library&nbsp;


		        <div class="pull-right">
		            <i class="icon-calendar icon-small"></i>
		            <?php
								$Today = date('y:m:d');
								$new = date('l, F d, Y', strtotime($Today));
								echo $new;
								?>
		        </div>
		    </div>


		</div>