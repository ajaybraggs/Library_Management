<?php include('header.php'); ?>
<?php include('navbar.php'); ?>
    <div class="container">
		<div class="margin-top">
			<div class="row">
					<?php include('head.php'); ?>
				<div class="span2">
					<?php include('sidebar.php'); ?>
				</div>
				<div class="span10">
				<iframe width="970" height="450" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" ti&amp;sll=10.646259,123.001728&amp;sspn=0.175117,0.338173&amp;ie=UTF8&amp;hq=STI+College+-+Bacolod,+26+Lacson+Street,+Dakbanwa+sang+Bacolod&amp;ll=10.685653,122.957305&amp;spn=0.001368,0.002642&amp;t=m&amp;z=14&amp;iwloc=A&amp;cid=10561904145727223193&amp;output=embed"></iframe><br /><small><a  style="color:#0000FF;text-align:left">View Larger Map</a></small>
				</div>
			</div>
		</div>
    </div>
<?php include('footer.php') ?>
