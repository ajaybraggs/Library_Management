			<div class="life-side-bar">
			<div class="hero-container">                  
			
					
			</div>
			
			
		
					
					
							<ul class="nav nav-tabs nav-stacked">
						<li class="">
						<a   href="#">&nbsp;    Contact US</a>
						</li>
					</ul>
<strong>Address</strong>
<p>VIT University, Vellore - 632014, Tamil Nadu, India </p>
<p>Telephone No. :</p>
<p>0542-2361727</p>



			
			</div>
			
	